%%*************************************************************************
%% Technische Hochschule Ingolstadt 
%%

%% an der Technische Hochschule Ingolstadt, Fakultät Informatik 
%%*************************************************************************